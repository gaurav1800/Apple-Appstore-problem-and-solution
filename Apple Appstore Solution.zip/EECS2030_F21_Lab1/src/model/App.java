package model;


 
public class App {
	
	private String name;
	private String version;
	private String whatIsNew;
	private String ratingReport;
	
	private int index; // to keep track of how many user ratings are submitted
	private int maxRatings;
	private int nou; // number of updates
	int fives, fours, threes, twos, ones;
	private final int MAXIMUM_UPDATES = 20; // constant limit of number of updates initialized to 20
	
	private double sum;
	private double averageRating; //average of all the ratings submitted
	private int[] userRatings;
	
	private Log versionInfo;
	private Log log;
	private Log[] updateHistory;
	
	
	
	public App() {
		//do nothing; just to initialize the variables to their default values
	}
	
	
	public App(String name, int maxRatings) {
		this.name = name;
		this.maxRatings = maxRatings;
		this.updateHistory = new Log[MAXIMUM_UPDATES];
		this.userRatings = new int[this.maxRatings];
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getMaxRatings() {
		return this.maxRatings;
	}
	
	public void releaseUpdate(String version) {
		this.version = version;
		Log log = new Log(this.version);
		this.log = log;
		this.updateHistory[this.nou] = this.log;
		this.nou++;
		this.whatIsNew = "";
	}
	
	public String getWhatIsNew() {
		if(whatIsNew == null) {
			String s = "n/a"; 
			return s;
		}
		else {
			return this.getUpdateHistory()[this.nou - 1].toString();
		}
	}
	
	public Log[] getUpdateHistory() {
		
		Log[] logs = new Log[this.nou];
		for(int i = 0; i < this.nou; i++) {
			logs[i] = this.updateHistory[i];
		}
		return logs;
		
	}
	
	public Log getVersionInfo(String version) {
		for(int i = 0; i < this.nou; i++) {
			if (version == getUpdateHistory()[i].getVersion()) {
				this.versionInfo = getUpdateHistory()[i];
				break;
			}
			else {
				this.versionInfo = null;
			}
		}
		return this.versionInfo;
		
	}
	
	
	public void submitRating(int userRating) {
		
		this.userRatings[this.index] = userRating;
		if (userRatings[this.index] == 1) {
			ones += 1;
		}
		else if (userRatings[this.index] == 2) {
			twos += 1;
		}
		else if (userRatings[this.index] == 3) {
			threes += 1;
		}
		else if (userRatings[this.index] == 4) {
			fours += 1;
		}
		else if (userRatings[this.index] == 5) {
			fives += 1;
		}
		this.index++;
		
		
		this.ratingReport = "Average of " + this.index + " ratings: " + String.format("%.1f", getAverageRating()) + " (Score 5: " + fives +
			", Score 4: " + fours + ", Score 3: " + threes + ", Score 2: " + twos + ", Score 1: " + ones + ")";
	}
	
	public double getAverageRating() {
		double sum = 0;
		this.sum = sum;
		double averageRating = 0;
		
		// if only one number - return the number, else return average of all
		if(this.index == 1) {
			averageRating = userRatings[0];
		}
		else {
			
			for(int i = 0; i < this.index; i++) {
				this.sum += userRatings[i];
			}
			averageRating = this.sum / this.index; 				
		}
			
			this.averageRating = averageRating;
			return this.averageRating;		
		}

		
	
	public String getRatingReport() {
		if(this.ratingReport == null) {
			String s = "No ratings submitted so far!";
			return s;
		}
		
		else {
		return this.ratingReport;
		}
	}

		
	public String toString() {
		 String s = "";
		 s += this.name + " (Current Version: " + getWhatIsNew() + "; Average Rating: ";
		 if(averageRating == 0) {
			 s += "n/a)";
		 }
		 else {
			 s += String.format("%.1f", getAverageRating()) + ")";
		 }
		 return s;
	}
	

}
