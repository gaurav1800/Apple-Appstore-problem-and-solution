package model;

import static org.junit.Assert.assertEquals;

public class Log {
	private String version; // log version (e.g. 5.7.31)
	private int numberOfFixes;
	private final int MAXIMUM_FIXES = 10; // constant limit of 10 
	private String[] fixes = new String[MAXIMUM_FIXES];
	
	
	public Log() {
		//do nothing; just to set the attributes created to their default values
	}
	
	
	public Log(String version) {
		this.version = version;
	}
	
	
	public String getVersion() {
		return this.version;
	}
	
	
	public int getNumberOfFixes() {
		return this.numberOfFixes;
	}
	
	
	public void addFix(String fix) {
		fixes[numberOfFixes] = fix;
		numberOfFixes += 1;
	}
	
	
	
	public String getFixes() {
		if(numberOfFixes == 0) {
			return "[]";
		}
		else
		{
			String s = "[";
			for(int i = 0; i < numberOfFixes; i++) {
				if(i != numberOfFixes - 1) {	
					s += fixes[i];
					s += ", ";
				}
				else {
					s += fixes[i];
				}
			}
			s += "]";
			return s;
		}
	}

	public String toString() {
		String s = "Version " + version + " contains " + numberOfFixes + " fixes [";
		if (numberOfFixes == 0) {
			s += "]";
			return s;
		}
		else {
			for(int i = 0; i < numberOfFixes; i++) {
				if(i != numberOfFixes - 1) {	
					s += fixes[i];
					s += ", ";
				}
				else {
					s += fixes[i];
				}
			}
			s += "]";
			return s;
		}
	}

}
