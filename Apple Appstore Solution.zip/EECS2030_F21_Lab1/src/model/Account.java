package model;

public class Account {
	
	
	private int numOfDownloadedApps;
	private final int MAXIMUM_DOWNLOADS = 50;
	
	
	private String ownerName;
	private String appName;
	private String status;
	private String[] names; 
	private String[] namesOfDownloadedApps = new String[MAXIMUM_DOWNLOADS];

	
	private App app;
	private App[] apps;
	private App[] objects;

	private AppStore branchName;
	
	
	public Account() {
		//do nothing; just to initialize the variables to their default values
	}
	
	public Account(String ownerName, AppStore branchName) {
		this.ownerName = ownerName;
		this.branchName = branchName;
		String status = "An account linked to the " + branchName.getBranch() + " store is created for " + this.ownerName + ".";
		this.status = status;
	}
	
	public String getOwnerName() {
		return this.ownerName;
	}
	
	public AppStore getBranchName() {
		return this.branchName;
	}
	
	
	public void download(String name) {
		boolean appExists = false;
		for(int i=0; i < numOfDownloadedApps; i++) {
			if(namesOfDownloadedApps[i].equals(name)) { //equalsIgnoreCase?
				appExists = true;
				break;
			}
		}
		if(appExists) {
			status = "Error: " + name + " has already been downloaded for " + this.ownerName + ".";
		} else {
			namesOfDownloadedApps[numOfDownloadedApps] = name;
			numOfDownloadedApps++;
			status = name + " is successfully downloaded for " + this.ownerName + ".";
		}
	}
	
	
	public String[] getNamesOfDownloadedApps() {
		String[] names = new String[this.numOfDownloadedApps];
		this.names = names;
		for(int i = 0; i < this.numOfDownloadedApps; i++) {
			this.names[i] = this.namesOfDownloadedApps[i];	
		}
		return this.names;
		
	}
	
	
	public App[] getObjectsOfDownloadedApps() {
		App[] objects = new App[this.numOfDownloadedApps];
		this.objects = objects;
		
		App[] apps = new App[MAXIMUM_DOWNLOADS];
		this.apps = apps;
		
		for(int i = 0; i < this.numOfDownloadedApps; i++) {
			this.objects[i] = this.branchName.getApp(namesOfDownloadedApps[i]);
			
			this.apps[i] = this.branchName.getApp(namesOfDownloadedApps[i]);	
		}

		return objects;
	}
	
	
	public void uninstall(String appName) {
		int appIndex = -1;
		for(int i=0; i < numOfDownloadedApps; i++) {
			if(namesOfDownloadedApps[i].equals(appName)) { 
				appIndex = i;
				break;
			}
		}
		if(appIndex!=-1) {
			// uninstall app
			for(int i=appIndex;i<numOfDownloadedApps-1;i++) {
				namesOfDownloadedApps[i] = namesOfDownloadedApps[i+1];
			}
			namesOfDownloadedApps[numOfDownloadedApps - 1] = null;
			numOfDownloadedApps = numOfDownloadedApps - 1;
			status = appName + " is successfully uninstalled for " + this.ownerName + ".";
		} else {
			status = "Error: " + appName + " has not been downloaded for " + this.ownerName + ".";
		}
		
	}
	
	
	
	public void submitRating(String appName, int userRating) {
		String status = "";
		this.appName = appName;
		
		if(getNamesOfDownloadedApps().length == 0) {
			status = "Error: " + this.appName + " is not a downloaded app for " + this.ownerName + ".";
		}
		else if (appName == null && userRating == 0) {
			status = "No ratings submitted so far!";		
		}
		
		else {
			int i = 0;
			while(i != this.numOfDownloadedApps) {
				if (getNamesOfDownloadedApps()[i] == this.appName) {
						status = "Rating score " + userRating + " of " + this.ownerName + " is successfully submitted for " + this.appName + ".";
						this.app = getObjectsOfDownloadedApps()[i];
						this.app.submitRating(userRating);
						this.app.getAverageRating();
						break;
				}
				else {
					i++;
				}
				status = "Error: " + this.appName + " is not a downloaded app for " + this.ownerName + ".";
			}
		}

		this.status = status;	
		
		
	}
	
		
	public void switchStore(AppStore appStore) {
		String status;
		status = "Account for " + this.ownerName + " is now linked to the " + appStore.getBranch() + " store.";
		this.status = status;
	}
	
	public String toString() {
		return this.status;
	}
	
}


