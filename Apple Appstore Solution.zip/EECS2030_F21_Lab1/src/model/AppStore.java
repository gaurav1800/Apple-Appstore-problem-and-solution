package model;

public class AppStore {
	private String branch;
	private String[] stables;
	
	private App app;	
	private App[] apps;
	
	private int maximumApps;
	private int numOfStableApps;
	private int noa; // number of apps
	
	
	public AppStore() {
		//do nothing; just to initialize the values of the attributes to their default ones
	}
	
	public AppStore(String branch, int maximumApps) {
		this.branch = branch;
		this.maximumApps = maximumApps;
		apps = new App[this.maximumApps];
	}
	
	public String getBranch() {
		return this.branch;
	}
	
	public void addApp(App app) {
		 this.app = app;
		 this.apps[this.noa] = this.app;
		 this.noa++;
	}
		
	public App getApp(String name) {

		app = new App();
		
		for(int i = 0; i < this.noa; i++) {
			if (this.apps[i].getName() == name) {
				this.app = this.apps[i];
				return app;
			}
		}
		return null;
	}
	
 	
 	
 	public String[] getStableApps(int ut) {
 		stables = new String[maximumApps];
 		String[] stableApps;
 		this.numOfStableApps = 0;
 		
 		for(int i = 0; i < this.noa; i++) {
 			
	 		if(this.apps[i].getUpdateHistory().length >= ut) {
	 			String s = this.apps[i].getName() + " (" + this.apps[i].getUpdateHistory().length + " versions;";
	 			s += " Current Version: " + this.apps[i].getWhatIsNew() + ")";
	 			stables[this.numOfStableApps] = s;
	 			this.numOfStableApps++;
	 		}
 		}
 		stableApps = new String[this.numOfStableApps];
 		for(int i = 0; i < this.numOfStableApps; i++) {
 			stableApps[i] = stables[i];
 		}
 		
 		return stableApps;
 	}
 	
	
}
